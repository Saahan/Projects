
//declare two number variables

var num1 = 10;
let num2 = -2.5;

let str1 = "This isn't too bad";
var str2 = "this is a double qoute \" ";

var str3 = "This is line 1. \r\n This is line 2";

var noVal = null;

var str4 = "This is easy";

let starStr = "-";
let starRepeatStr = starStr.repeat(30);


console.log("value of num1 is : ", num1);
console.log("Value of Num2 " + num2);

console.log( str1.concat(" ",str2) );


console.log(str2);


var str5 = str4.toUpperCase();

//document.write(str3);

//alert(str3);
console.log(starRepeatStr,"Divide",starRepeatStr);

console.log(noVal);
console.log("The length of str4 is ", str4.length);
console.log("The char at last position is ", str4.charAt(str4.length-1));

console.log("The first index of s is ", str5.indexOf("S"));
console.log("The last index of s is ", str4.lastIndexOf("S"));


let concatStr = str1.concat(" ", str2);




console.log(starRepeatStr,"Start substr",starRepeatStr);


//substr(startIndex, number of chars) : 
let shortStr1 = concatStr.substr(6,-5);

console.log(concatStr);
console.log(shortStr1);

//substring
let shortStr2 = concatStr.substring(5,-3);
console.log(shortStr2);

let shortStr3 = concatStr.slice(5,11);

console.log(shortStr3);

//match
console.log(starRepeatStr,"Match",starRepeatStr);

let matchStr = concatStr.match(/This/gi);

console.log("match str is " + matchStr.length);

var newConcatStr = concatStr.replace(/This/gi,"That");

console.log(newConcatStr);


//Mathematical operators (+,-,*,/, %)

let num3 = 25;
let num4 = 5;
let num5 = 3;

let num6 = "30";
let num7 = "10";

console.log(starRepeatStr,"Mathematical operators",starRepeatStr);




console.log(num3 , '+', num4, num3 + num4 );

console.log(num3 + "+" + num4 + " " + (num3 + num4) );

console.log(+num6 + +num7);


console.log(num6 - num7);
console.log(num6 * num7);
console.log(num6 / num7);

console.log(num3 / num5); //division

console.log(5 % 2); //modulo % : shows remainder.