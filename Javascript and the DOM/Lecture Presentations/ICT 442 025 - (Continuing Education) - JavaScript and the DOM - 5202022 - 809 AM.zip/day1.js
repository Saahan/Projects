
//My first javaScript

/*

Started on Thursday Feb 24
This is the first class

*/

//declare a variable

var _10Messages = "This is just a test";


//console.log(myCity);

var myName = "Adnan",myAge = 10,myAddress = "xyz";

var myAge = 20;

console.log(myAge);

//let



	{
	let myFirstName = "ADNAN";
	console.log(myFirstName);
	}






//const

const myType = "Human";

myType = "Robot";
console.log(myType);



console.log(_10Messages);
console.log(_10Messages);
console.log(_10Messages);
console.log(_10Messages);
console.log(_10Messages);
console.log(_10Messages);
console.log(_10Messages);
console.log(_10Messages);
console.log(_10Messages);
console.log(_10Messages);
console.log(_10Messages);
console.log(_10Messages);