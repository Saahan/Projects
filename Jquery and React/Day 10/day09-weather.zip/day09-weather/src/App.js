import logo from './logo.svg';
import './App.css';
import Main from './components/main';
import Add, { myConstant } from './components/day9-demo1-jsexport'
//import { myConstant } from './components/day9-demo1-jsexport'
function App() {
  console.log(Add(2, 3))
  console.log('Application started.......')
  const r = Add(2, 3);
  return (
    <div>
      <h3>2+3= {r}, my Const = </h3>
      <Main />
    </div>
  );
}

export default App;
