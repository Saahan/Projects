// Demo exporting element
export default function add(x, y) {
    return x + y;
}

exports.myConstant = 44;